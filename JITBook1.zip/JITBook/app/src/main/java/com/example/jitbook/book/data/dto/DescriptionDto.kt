package com.example.jitbook.book.data.dto

import kotlinx.serialization.Serializable

@Serializable
data class DescriptionDto(
    val value: String,
)
