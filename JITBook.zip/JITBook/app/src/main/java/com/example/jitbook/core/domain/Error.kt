package com.example.jitbook.core.domain

import kotlin.Result

interface Error