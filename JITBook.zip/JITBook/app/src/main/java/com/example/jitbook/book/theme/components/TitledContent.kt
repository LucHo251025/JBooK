package com.example.jitbook.book.theme.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun TitledContent(
    title: String,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
}